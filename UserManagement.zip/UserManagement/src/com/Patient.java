package com;

import java.sql.*;

public class Patient {
	
	private Connection connect(){
		
		Connection con = null;
				try
					{
					Class.forName("com.mysql.jdbc.Driver");
					//Provide the correct details: DBServer/DBName, username, password
					con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/usermanagement", "root", "root#Root");
					}
				catch (Exception e){
					e.printStackTrace();
				}
		return con;
		
		}
		
		//insert-----------------------------------------------------------------------------------------------------------------------------
		
		public String insertPatient(String username, String p_password, String firstName, String lastName, String email_add, String p_Age, String contactNo)
	    {
				String output = "";
				try
				{
					Connection con = connect();
					if (con == null)
					{    
						return "Error while connecting to the database for inserting.";
					}
					// create a prepared statement
					String query = "insert into patient"
							+"(`p_id`,`user_name`,`password`,`first_name`,`last_name`,'email ','age ','contact_no')"
							 + " values (?, ?, ?, ?, ?, ?, ?, ?)";
							PreparedStatement preparedStmt = con.prepareStatement(query); 
					// binding values
					preparedStmt.setInt(1, 0);
					preparedStmt.setString(2, username);
					preparedStmt.setString(3, p_password);
					preparedStmt.setString(4, firstName);
					preparedStmt.setString(5, lastName);
					preparedStmt.setString(6, email_add);
					preparedStmt.setInt(7, Integer.parseInt(p_Age));
					preparedStmt.setInt(8, Integer.parseInt(contactNo));

		
					// execute the statement
					preparedStmt.execute();
					con.close();
					
					String newPatient = readPatient();
					output = "{\"status\":\"success\", \"data\": \"" +newPatient + "\"}";
				}
					catch (Exception e)
				{
						output = "{\"status\":\"error\", \"data\": \"Error while inserting the item.\"}";
						System.err.println(e.getMessage());
				}
				return output;
	    		}
		
		
		//view------------------------------------------------------------------------------------------------------------------------
		public String readPatient(){
			
			String output = "";
				try{
				Connection con = connect();
				
				if (con == null){
					return "Error while connecting to the database for reading."; 
				}
				// Prepare the html table to be displayed
				output = "<table border='1'>"
						+ "<tr><th> Patient's Username</th>"
						+ "<th> Patient's Name </th>"
						+ "<th> Patient's Email address </th>"
						+ "<th> Patient's Age </th>"
						+ "<th> Patient's Contact Number </th>"
						+ "<th>Update</th>"
						+ "<th>Remove</th></tr>";
				
				String query = "select * from patient";
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				// iterate through the rows in the result set
				while (rs.next()){
					
					String p_id = Integer.toString(rs.getInt("p_id"));
					String user_name = rs.getString("user_name");
					String password = rs.getString("password");
					String first_name = rs.getString("first_name");
					String last_name = rs.getString("last_name");
					String email = rs.getString("email");
					String age = Integer.toString(rs.getInt("age"));
					String contact_no = Integer.toString(rs.getInt("contact_no"));

					
					// Add into the html table
					output += "<tr><td><input id='hidPatientIDUpdate' name='hidPatientIDUpdate' type='hidden' value='" + p_id+ "'>" + user_name + "</td>";
					output += "<td>" + first_name +" "+ last_name + "</td>";
					output += "<td>" + email + "</td>";
					output += "<td>" + age + "</td>";
					output += "<td>" + contact_no + "</td>";
					 // buttons
					
					output += "<td><input name='btnUpdate'type='button' "
							+ "value='Update'class='btnUpdate btn btn-secondary'></td>"
							+ "<td><input name='btnRemove'type='button' "
							+ "value='Remove'class='btnRemove btn btn-danger'data-itemid='"+ p_id + "'>" + "</td></tr>";
				}
				
				con.close();
				// Complete the html table
				output += "</table>";
				}
				catch (Exception e){
					output = "Error while reading the Patient.";
					System.err.println(e.getMessage());
				}
				
		return output;
		
		}
		
		
		//update----------------------------------------------------------------------------------------------------------------
		public String updatePatient(String p_ID, String username,String p_password, String firstName, String lastName, String email_add, String p_Age, String contactNo) {
			String output = "";
			try {
				Connection con = connect();
				if (con == null) {
					return "Error while connecting to the database for updating.";
				}
				// create a prepared statement
				String query = "UPDATE patient SET user_name=?,password=?,first_name=?,last_name=?,email=?,age=?,contact_no=? WHERE p_id=?";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				// binding values
				preparedStmt.setString(1, username);
				preparedStmt.setString(2, p_password);
				preparedStmt.setString(3, firstName);
				preparedStmt.setString(4, lastName);
				preparedStmt.setString(5, email_add);
				preparedStmt.setInt(6, Integer.parseInt(p_Age));
				preparedStmt.setInt(7, Integer.parseInt(contactNo));
				preparedStmt.setInt(8, Integer.parseInt(p_ID));
				// execute the statement
				preparedStmt.execute();
				con.close();
				
				String newPatient = readPatient();
				output = "{\"status\":\"success\", \"data\": \"" + newPatient + "\"}";;
			} catch (Exception e) {
				output = "{\"status\":\"error\", \"data\": \"Error while updating the patient details.\"}";
				System.err.println(e.getMessage());
			}
			return output;
		}

		
		//delete-------------------------------------------------------------------------------------------------------------------
		public String deletePatient(String p_id) {
			String output = "";
			try {
				Connection con = connect();
				if (con == null) {

					return "Error while connecting to the database for deleting.";
				}
				// create a prepared statement
				String query = "delete from patient where p_id=?";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				// binding values
				preparedStmt.setInt(1, Integer.parseInt(p_id));
				// execute the statement
				preparedStmt.execute();
				con.close();
				
				String newPatient = readPatient();
				output = "{\"status\":\"success\", \"data\": \"" + newPatient + "\"}";
			} catch (Exception e) {
				output = "{\"status\":\"error\", \"data\": \"Error while deleting the patient.\"}";
				System.err.println(e.getMessage());
			}
			return output;
		}

}
